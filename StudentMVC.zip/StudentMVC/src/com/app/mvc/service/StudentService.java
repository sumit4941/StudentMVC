package com.app.mvc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.mvc.DAO.StudentDAO;
import com.app.mvc.DTO.StudentDTO;

@Service
public class StudentService {

	
	@Autowired
	private StudentDAO dao;
	
	public void register(StudentDTO dto) {
		dao.register1(dto);
	}
	public List<StudentDTO> loadFromDAO() {
		/*List<MatrimonyDTO>matrimonyDAOs = dao.loadAllData();
		return matrimonyDAOs;*/
		//Above line replacement for code optimization
		return dao.loadData();
	}

}

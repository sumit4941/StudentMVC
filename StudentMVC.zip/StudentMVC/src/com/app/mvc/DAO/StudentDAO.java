package com.app.mvc.DAO;

import com.app.mvc.DTO.CollegeDTO;
import com.app.mvc.DTO.StudentDTO;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


@Repository
public class StudentDAO {

	
	@Autowired
	private SessionFactory sf;
	
	public void register1(StudentDTO dto) {
		Session sess=sf.openSession();
		sess.save(dto);
		sess.beginTransaction().commit();
	}
	public void register2(CollegeDTO dto) {
			Session sess=sf.openSession();
			sess.save(dto);
			sess.beginTransaction().commit();	
	}	
	
	@SuppressWarnings("unchecked")
	public List<StudentDTO> loadData() {	
			return sf.openSession().createCriteria(StudentDTO.class).list();
		}
	}
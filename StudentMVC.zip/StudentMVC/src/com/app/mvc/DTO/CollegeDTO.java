package com.app.mvc.DTO;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@SuppressWarnings("serial")
@Entity
@Table(name = "education_table")
public class CollegeDTO implements Serializable{

	@Id
	@Column(name = "reg_no")
	private int regno;

	@Column(name = "college_name")
	private String college;
	@Column(name = "university_name")
	private String university;

	@JoinColumn(name="reg_no")
	@OneToMany(cascade=CascadeType.ALL)
	private StudentDTO student;

	public int getRegno() {
		return regno;
	}

	public void setRegno(int regno) {
		this.regno = regno;
	}

	public String getCollege() {
		return college;
	}

	public void setCollege(String college) {
		this.college = college;
	}

	public String getUniversity() {
		return university;
	}

	public void setUniversity(String university) {
		this.university = university;
	}

	public StudentDTO getStudent() {
		return student;
	}

	public void setStudent(StudentDTO student) {
		this.student = student;
	}
}

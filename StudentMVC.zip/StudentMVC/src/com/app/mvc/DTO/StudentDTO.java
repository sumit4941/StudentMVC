package com.app.mvc.DTO;

import java.io.Serializable;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;



@SuppressWarnings("serial")
@Entity
@Table(name = "Students_table")
public class StudentDTO implements Serializable {

	
	@Id
	@GenericGenerator(name="gen",strategy="increment")
	@GeneratedValue(generator="gen")
	@Column(name="reg_no")
	private int regno;
	
	@Column(name="stu_name")
	private String name;
	
	@Column(name="stu_age")
	private int age;

	@Column(name="stu_gender")
	private String gender;

	@JoinColumn(name="reg_no")
	@ManyToOne(cascade=CascadeType.ALL)
	
	private CollegeDTO coll;
	
	
	public int getRegno() {
		return regno;
	}

	public void setRegno(int regno) {
		this.regno = regno;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public CollegeDTO getColl() {
		return coll;
	}

	public void setColl(CollegeDTO coll) {
		this.coll = coll;
	}
}

package com.app.mvc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.app.mvc.DTO.CollegeDTO;
import com.app.mvc.DTO.StudentDTO;
import com.app.mvc.service.StudentService;


@Controller
@Component
@RequestMapping("/")
public class StudentController {

	@Autowired
	private StudentService service;
	
	public StudentController() {
		System.out.println("Controller Constructor");
	}
		@RequestMapping(value="/register.do",method=RequestMethod.POST)
		public ModelAndView register(@ModelAttribute StudentDTO dto) {
			service.register(dto);
			ModelAndView mv =  new ModelAndView();
			mv.setViewName("success");
			return mv ; 
		}
		
		@RequestMapping(value="/search.do",method=RequestMethod.POST)
		public ModelAndView search(@ModelAttribute StudentDTO dto) {
			service.loadFromDAO();
			CollegeDTO col = new CollegeDTO();
			ModelAndView mv =  new ModelAndView();
			mv.setViewName("loadStudent");
			mv.addObject("regno",dto.getRegno());
			mv.addObject("name",dto.getName());
			mv.addObject("age",dto.getAge());
			mv.addObject("gender",dto.getGender());
			mv.addObject("college",col.getCollege());
			mv.addObject("university",col.getUniversity());
			return mv ; 
		}
		
	}